
$('.carousel').carousel({
    interval: 7000
})

$('.carousel').carousel({
    pause: "hover"
})

